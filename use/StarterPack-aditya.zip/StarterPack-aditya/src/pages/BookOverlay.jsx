/* ------------------------------------------------------------------ */
/*  BOOK (diary) OVERLAY                                               */
/* ------------------------------------------------------------------ */
import { useEffect, useState, useRef, useLayoutEffect } from "react";
import { diaryInput } from "../services/diaryServices.js";

import "../styles/Categories.css"

function BookOverlay({ open, onClose }) {
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState("");
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");

  // Category State
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [category, setCategory] = useState("");
  const [categoryColor, setCategoryColor] = useState("");
  const [categoryId,setCategoryId]=useState("");

  // Handling the Title Input ( Auto fitting title )
  const ref = useRef(null);

  useLayoutEffect(() => {
    const title = ref.current;
    if (!title) return;

    const LINES = 3;
    const LH = 1.05;
    const MIN = 6;
    const RATIO = 0.6;
    const STEP = 0.5;

    const mirror = document.createElement("div");
    document.body.appendChild(mirror);

    const setSize = (s) => {
      title.style.fontSize = s + "px";
      title.style.letterSpacing = s * 0.09 + "px";
    };

    const textHeight = (s) => {
      const cs = getComputedStyle(title);
      const m = mirror.style;
      m.cssText =
        "position:absolute;left:-9999px;top:0;visibility:hidden;" +
        "box-sizing:border-box;white-space:pre-wrap;" +
        "overflow-wrap:anywhere;word-break:break-word;";
      m.width = title.clientWidth + "px";
      m.fontFamily = cs.fontFamily;
      m.fontWeight = cs.fontWeight;
      m.paddingLeft = cs.paddingLeft;
      m.paddingRight = cs.paddingRight;
      m.fontSize = s + "px";
      m.letterSpacing = s * 0.09 + "px";
      m.lineHeight = LH;
      mirror.textContent = (title.value || " ") + "\u200b";
      return mirror.offsetHeight;
    };

    const fitTitle = () => {
      const boxH = title.clientHeight;
      if (!boxH) return;
      const MAX = Math.floor(boxH / (LINES * LH));
      let size = MAX;
      while (textHeight(size) > size * LH * 1.5 && size > MAX * RATIO)
        size -= STEP;
      while (textHeight(size) > boxH && size > MIN) size -= STEP;
      setSize(size);
      title.scrollTop = 0;
    };

    const onKeyDown = (e) => {
      if (e.key === "Enter") e.preventDefault();
    };
    const onInput = () => {
      if (/\n/.test(title.value))
        title.value = title.value.replace(/\s*\n+\s*/g, " ");
      fitTitle();
    };

    title.addEventListener("keydown", onKeyDown);
    title.addEventListener("input", onInput);
    const ro = new ResizeObserver(fitTitle);
    ro.observe(title);
    window.addEventListener("resize", fitTitle);
    fitTitle();

    return () => {
      title.removeEventListener("keydown", onKeyDown);
      title.removeEventListener("input", onInput);
      ro.disconnect();
      window.removeEventListener("resize", fitTitle);
      mirror.remove();
    };
  }, []);

  // Close dropdown when clicking outside or pressing Escape
  useEffect(() => {
    const handleOutsideClick = () => setDropdownOpen(false);
    const handleKeyDown = (e) => {
      if (e.key === "Escape") setDropdownOpen(false);
    };

    if (dropdownOpen) {
      document.addEventListener("click", handleOutsideClick);
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.removeEventListener("click", handleOutsideClick);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [dropdownOpen]);

  // Free the blob URL when it's replaced / on unmount
  useEffect(() => {
    return () => {
      if (imagePreview) URL.revokeObjectURL(imagePreview);
    };
  }, [imagePreview]);

  const handleSave = async (e) => {
    // Optional: make sure element exists before attempting to remove class
    // const showEl = document.getElementsByClassName("show");
    // if (showEl.length > 0) {
    //   showEl[0].classList.remove("show");
    // }
    onClose()
    console.log("Stick : ", imagePreview);
    const response = await diaryInput({ title, desc, imageFile, categoryId });
    console.log(response);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
      console.log("Image preview : ", imagePreview)
    }
  };

  return (
    <div
      className={`book-overlay ${open ? "show" : ""}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="book">
        <button
          className="close-book"
          type="button"
          onClick={onClose}
        >
          &times;
        </button>

        <div className="book-cover-title">
          <span>PERSONAL COLLECTION · 001</span>
          <h1>STARTER PACK</h1>
          <p>A LITTLE SPACE FOR EVERYTHING</p>
        </div>

        <div className="book-pages">
          {/* IMAGE PAGE */}
          <div className="page image-page">
            <button
              type="button"
              className="stick-btn"
              onClick={handleSave}
            >
              stick
            </button>

            <div className="image-area">
              <div className="polaroid-frame">
                <div className="polaroid-photo">
                  {imagePreview && (
                    <img
                      src={imagePreview}
                      alt="Uploaded preview"
                    />
                  )}
                </div>

                <div
                  className="polaroid-chin"
                  onClick={(e) => e.stopPropagation()}
                >
                  <span className="chin-label">CATEGORY:</span>

                  <div className={`chin-dropdown ${dropdownOpen ? "open" : ""}`} id="chinDropdown">
                    <button
                      type="button"
                      className="chin-trigger"
                      id="chinTrigger"
                      aria-haspopup="listbox"
                      aria-expanded={dropdownOpen}
                      onClick={(e) => {
                        e.stopPropagation();
                        setDropdownOpen((prev) => !prev);
                      }}
                    >
                      <span
                        className={`chin-dot ${category ? "visible" : ""}`}
                        id="chinCurrentDot"
                        style={{ background: categoryColor }}
                      ></span>
                      <span
                        className={`chin-value ${category ? "has-value" : ""}`}
                        id="chinCurrentText"
                      >
                        {category || "pick one..."}
                      </span>
                      <span className="chin-arrow">▾</span>
                    </button>

                    <ul
                      className="chin-menu"
                      id="chinMenu"
                      role="listbox"
                      aria-label="Idea Category"
                    >
                      {[
                        { id: 1, val: "Tech", color: "#ffd23f", name: "TECH", note: "code & gadgets" },
                        { id: 2, val: "Design", color: "#ef5c9a", name: "DESIGN", note: "ui & visuals" },
                        { id: 3, val: "Art", color: "#67a7d6", name: "ART", note: "print & ink" },
                        { id: 4, val: "Startup", color: "#97b538", name: "STARTUP", note: "big ventures" },
                        { id: 5, val: "Random", color: "#e68638", name: "WILD", note: "shower thoughts" },
                      ].map((item) => (
                        <li
                          key={item.val}
                          className={`chin-option ${category === item.val ? "selected" : ""}`}
                          role="option"
                          data-value={item.val}
                          data-color={item.color}
                          onClick={() => {
                            setCategory(item.val);
                            setCategoryId(item.id);
                            setCategoryColor(item.color);
                            setDropdownOpen(false);
                          }}
                        >
                          <span
                            className="opt-swatch"
                            style={{ background: item.color }}
                          ></span>
                          <span className="opt-name">{item.name}</span>
                          <span className="opt-note">{item.note}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Hidden input for backend compatibility */}
                    <input
                      type="hidden"
                      id="ideaCategory"
                      value={category}
                    />
                  </div>
                </div>
              </div>
            </div>

            <input
              type="file"
              id="imageUpload"
              accept="image/*"
              hidden
              onChange={handleImageChange}
            />

            <label
              htmlFor="imageUpload"
              className="pencil-btn"
              title="Add image"
            >
              <svg
                viewBox="0 0 24 24"
                width="19"
                height="19"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.7"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 20h9" />
                <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" />
              </svg>
            </label>
          </div>

          {/* WRITING PAGE */}
          <div className="page writing-page">
            <textarea
              className="title-input"
              placeholder="Title"
              rows={3}
              maxLength={60}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />

            <textarea
              className="descriptionArea"
              placeholder="Your vision (no essays, show us that it was YOUR idea)"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
            />

            <span className="page-number">02</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BookOverlay;